// ==========================
// CONFIG ADM
// ==========================
const ADMIN_USER = "admin";
const ADMIN_PASS = "1019";

// ==========================
// ARMAZENAMENTO LOCAL
// ==========================
function getUsuarios() {
    return JSON.parse(localStorage.getItem("usuarios") || "[]");
}

function salvarUsuarios(lista) {
    localStorage.setItem("usuarios", JSON.stringify(lista));
}

function getLogins() {
    return JSON.parse(localStorage.getItem("logins") || "[]");
}

function salvarLogins(lista) {
    localStorage.setItem("logins", JSON.stringify(lista));
}

// ==========================
// TELAS
// ==========================
function mostrarTela(id) {
    document.querySelectorAll(".tela").forEach(t => t.style.display = "none");
    if (id) {
        document.getElementById(id).style.display = "block";
    }
}

function voltar() {
    mostrarTela("");
}

// ==========================
// CADASTRO
// ==========================
function cadastrar() {
    const nome = document.getElementById("cadNome").value.trim();
    const email = document.getElementById("cadEmail").value.trim();
    const idade = document.getElementById("cadIdade").value.trim();
    const gosta = document.getElementById("cadGosta").value.trim();
    const senha = document.getElementById("cadSenha").value.trim();

    const msgEl = document.getElementById("msgCadastro");
    msgEl.textContent = "";

    if (!nome || !email || !idade || !gosta || !senha) {
        msgEl.textContent = "Preencha tudo!";
        msgEl.style.color = "red";
        return;
    }

    const usuarios = getUsuarios();
    if (usuarios.find(u => u.email === email)) {
        msgEl.textContent = "Email já cadastrado!";
        msgEl.style.color = "red";
        return;
    }

    usuarios.push({ nome, email, idade, gosta, senha });
    salvarUsuarios(usuarios);

    msgEl.textContent = "Usuário cadastrado!";
    msgEl.style.color = "lightgreen";
}

// ==========================
// LOGIN USUARIO
// ==========================
function loginUsuario() {
    const email = document.getElementById("loginEmail").value.trim();
    const senha = document.getElementById("loginSenha").value.trim();
    const msgEl = document.getElementById("msgLogin");
    msgEl.textContent = "";

    const usuarios = getUsuarios();
    const u = usuarios.find(x => x.email === email && x.senha === senha);
    if (!u) {
        msgEl.textContent = "Dados incorretos!";
        msgEl.style.color = "red";
        return;
    }

    // registra login
    const logs = getLogins();
    logs.push({
        nome: u.nome,
        email: u.email,
        hora: new Date().toLocaleString()
    });
    salvarLogins(logs);

    // mostrar tela de usuário
    atualizarListaGeral();
    mostrarTela("telaUsuario");
}

// ==========================
// LOGIN ADM
// ==========================
function loginADM() {
    const u = document.getElementById("admUser").value;
    const s = document.getElementById("admSenha").value;
    const msgEl = document.getElementById("msgADM");
    msgEl.textContent = "";

    if (u === ADMIN_USER && s === ADMIN_PASS) {
        atualizarADM();
        mostrarTela("telaADM");
    } else {
        msgEl.textContent = "Dados incorretos!";
        msgEl.style.color = "red";
    }
}

// ==========================
// ADM ATUALIZA LISTAS
// ==========================
function atualizarADM() {
    const usuarios = getUsuarios();
    const logs = getLogins();

    let out = "";
    usuarios.forEach(u => {
        out += `Nome: ${u.nome}\nEmail: ${u.email}\nIdade: ${u.idade}\nGosta: ${u.gosta}\nSenha: ${u.senha}\n---------------------------\n`;
    });
    document.getElementById("listaUsuarios").textContent = out;

    let out2 = "";
    logs.forEach(l => {
        out2 += `${l.hora} - ${l.nome} (${l.email}) entrou\n`;
    });
    document.getElementById("listaLogins").textContent = out2;
}

// ==========================
// USUARIO LISTA GERAL
// ==========================
function atualizarListaGeral() {
    const usuarios = getUsuarios();
    let out = "";
    usuarios.forEach(u => {
        out += `Nome: ${u.nome}\nEmail: ${u.email}\nIdade: ${u.idade}\nGosta: ${u.gosta}\n---------------------------\n`;
    });
    document.getElementById("listaGeral").textContent = out;
}
